# My Cute Home Prototype
A simple React app to simulate your home layout.