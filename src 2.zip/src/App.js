
import React, { useState } from 'react';

export default function App() {
  const [room, setRoom] = useState('Living Room');
  const [activity, setActivity] = useState('Relaxing');

  return (
    <div style={{ fontFamily: 'Arial', textAlign: 'center', padding: 20 }}>
      <h1>🏡 My Cute Home</h1>
      <p>You are in: <b>{room}</b></p>
      <p>Doing: <b>{activity}</b></p>

      <h3>Change Room:</h3>
      <button onClick={() => setRoom('Living Room')}>Living Room</button>
      <button onClick={() => setRoom('Bedroom')}>Bedroom</button>
      <button onClick={() => setRoom('Kitchen')}>Kitchen</button>
      <button onClick={() => setRoom('Washroom')}>Washroom</button>

      <h3>Change Activity:</h3>
      <button onClick={() => setActivity('Watching TV')}>📺 TV</button>
      <button onClick={() => setActivity('Sleeping')}>😴 Sleeping</button>
      <button onClick={() => setActivity('Listening to Music')}>🎧 Music</button>
      <button onClick={() => setActivity('Gaming')}>🎮 Gaming</button>
    </div>
  );
}
